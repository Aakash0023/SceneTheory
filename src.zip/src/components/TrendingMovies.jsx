import MovieCard from "./MovieCard";

const TrendingMovies = ({ movies = [] }) => {
  return (
    <section className="trending-section">
      <div className="section-header">
        <p className="section-eyebrow">What's Trending</p>

        <h2 className="section-title">Trending Movies</h2>
      </div>

      <div className="trending-grid">
        {movies
          .filter((movie) => movie.poster_path)
          .map((movie) => (
            <MovieCard
              key={movie.id}
              id={movie.id}
              title={movie.title}
              image={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
            />
          ))}
      </div>
    </section>
  );
};

export default TrendingMovies;
