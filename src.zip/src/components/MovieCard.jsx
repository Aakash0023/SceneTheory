import { Link } from "react-router-dom";

const MovieCard = (props) => {
  console.log("FULL PROPS:", props);

  const { id, title, image } = props;

  return (
    <Link
      to={`/movie/${id}`}
      className="movie-link"
      onClick={() => {
        console.log("CLICKED ID:", id);
        alert(`ID = ${id}`);
      }}
    >
      <div className="poster-card">
        <img src={image} alt={title} className="poster-image" />
      </div>
    </Link>
  );
};

export default MovieCard;
