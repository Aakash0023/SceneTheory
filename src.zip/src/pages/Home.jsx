import { useEffect, useState } from "react";
import Navbar from "../Components/Navbar";
import Hero from "../Components/Hero";
import TrendingMovies from "../Components/TrendingMovies";
import SearchResults from "../Components/SearchResults";
import Features from "../Components/Features";
import Footer from "../Components/Footer";
import Community from "../Components/Community";
import Watchlists from "../Components/Watchlists";

import { fetchTrendingMovies, searchMovies } from "../api/tmdb";

const Home = () => {
  const [movies, setMovies] = useState([]);
  const [searchResults, setSearchResults] = useState([]);

  useEffect(() => {
    const getTrending = async () => {
      const data = await fetchTrendingMovies();
      setMovies(data);
    };

    getTrending();
  }, []);

  const handleSearch = async (query) => {
    const data = await searchMovies(query);

    setSearchResults(data);

    setTimeout(() => {
      document
        .getElementById("search-results")
        ?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  return (
    <>
      <Navbar onSearch={handleSearch} />

      <Hero />

      <TrendingMovies movies={movies} />

      <div id="search-results">
        <SearchResults movies={searchResults} />
      </div>

      <Features />

      <Community />

      <Watchlists />

      <Footer />
    </>
  );
};

export default Home;
